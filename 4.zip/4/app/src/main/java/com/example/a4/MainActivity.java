package com.example.a4;


import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText first,second,third, average;
    String grade1,grade2,grade3,resultMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnCompute = (Button) findViewById(R.id.btnCompute2);
        btnCompute.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Toast.makeText(this, "Done computing", Toast.LENGTH_LONG).show();
        ComputeResult();
    }

    private void ComputeResult() {
        first = (EditText) findViewById(R.id.grade1);
        second = (EditText) findViewById(R.id.grade2);
        third = (EditText) findViewById(R.id.grade3);
        average = (EditText) findViewById(R.id.result);

        int num1 = Integer.parseInt(first.getText().toString());
        int num2 = Integer.parseInt(second.getText().toString());
        int num3 = Integer.parseInt(third.getText().toString());
        float avg = (num1 + num2 + num3) / 3;
        average.setText(Float.toString(avg));

        Bundle args = new Bundle();
        args.putString("result", resultMessage);

        // Create a dialog instance
       DialogFragmentCustom dialogFragmentImp = new DialogFragmentCustom();
        // Pass on dialog argument(args), the result
       dialogFragmentImp.setArguments(args);
        // Display the Dialog
        dialogFragmentImp.show(getSupportFragmentManager(), "Display Result");
        // Reset EditTexts
       clearEditText();
    }
  public void clearEditText(){
       first.getText().clear();
     second.getText().clear();
     third.getText().clear();
     //average.getText().clear();
 //average.requestFocus();

    }
}

//}

